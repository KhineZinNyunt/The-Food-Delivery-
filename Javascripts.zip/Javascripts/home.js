
/*************** Get data from textbox and Validate if textboxes are empty************************/

	function getTextBox_value() {
		var Fname=document.getElementById('form_name').value;
		var Femail=document.getElementById('form_email').value;
		var Fmessage=document.getElementById('form_message').value;
		var errormsg="";
		if (Fname=="") 
		{
		  errormsg+="Please enter your name! \n";
		  document.getElementById('form_name').style.borderColor="#e63c60";
		}
		if (Femail=="") 
		{
		  errormsg+="Please enter your email! \n";
		  document.getElementById('form_email').style.borderColor="#e63c60";
		}
		if (Fmessage=="") 
		{
		  errormsg+="Please enter your message! \n";
		  document.getElementById('form_message').style.borderColor="#e63c60";
		}
		if(errormsg != "")
		{
		  alert(errormsg);
		  return false;
		}
		if(errormsg=true)
		{
		  alert('Your message has been sent successfully!!!');

		  document.getElementById('form_name').value = null;
		  document.getElementById('form_email').value = null;
		  document.getElementById('form_message').value = null;

		  document.getElementById('form_name').style.borderColor = "#008f77";
		  document.getElementById('form_email').style.borderColor = "#008f77";
		  document.getElementById('form_message').style.borderColor = "#008f77";
		}
	}	
/************************ when button is clicked , go to the top of homepage *****************************/

    window.onscroll = function() {scrollFunction()};

    function scrollFunction() {
    if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) 
    {
      document.getElementById("myBtn").style.display = "block";
    } else {
              document.getElementById("myBtn").style.display = "none";
           }
    }

    function topFunction() {
      document.body.scrollTop = 0;
      document.documentElement.scrollTop = 0;
    }
/**************************** Image slider animation and button on click next image, previous image ********** */

  	// contain images in an array
    var image = ['../Pictures/Homepage/main1_uneditited','../Pictures/Homepage/main2','../Pictures/Homepage/main3','../Pictures/Homepage/main4','../Pictures/Homepage/main5'];
    var i = image.length;
    var dummy = "img";

    // function for next slide 
    function nextImage(){
    	if (i<image.length) {
    		i= i+1;
    	}else{
    		i = 1;
    	}
    	slider_content.innerHTML = "<img class = "+dummy+" src= " +image[i-1]+ ".jpg>";
    }

    // function for prew slide
    function prewImage(){

    	if (i<image.length+1 && i>1) {
    		i= i-1;
    	}else{
    		i = image.length;
    	}
    	  slider_content.innerHTML = "<img class = "+dummy+"  src="+image[i-1]+".jpg>";
    }
    // script for auto image slider
    setInterval(nextImage , 4000);
/**************************************************************************************************/
